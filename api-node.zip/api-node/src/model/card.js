const { Sequelize, DataTypes } = require('sequelize')
const sequelize = require('../config/database')

const Card = sequelize.define('Cards',
    {
        id:{
            type: DataTypes.UUIDV4,
            primaryKey: true
        },
        nome:{
            type: DataTypes.STRING,
            allowNull: false
        },
        descricao: {
            type: DataTypes.STRING,
            allowNull: false,
           
            urlImagem: {
                type: DataTypes.STRING,
                allowNull: false
            },

            ataque: {
                type: DataTypes.INTEGER,
                allowNull: false
            },
            defesa: {
                type: DataTypes.INTEGER,
                allowNull: false
            },
            nivel: {
                type: DataTypes.INTEGER,
                allowNull: false
            },

            custo: {
                type: DataTypes.INTEGER,
                allowNull: false
            },
        }
    }
)

module.exports = User;