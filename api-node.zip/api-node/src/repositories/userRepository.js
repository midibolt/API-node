const User = require('../model/user');

class UserRepository {
    async createUser(user){
        return await User.create(user);
    }

    async findAll(){
        return await User.findAll();
    }

    async findByUserName(username){
        return await User.findOne({ where: {username}})
    }

    async delete(id){
        await User.destroy({where: {id}})

    }
}

module.exports = new UserRepository();