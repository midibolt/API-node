const Card = require('../model/card');

class CardRepository {
    async createCard(card){
        return await Card.create(card);
    }

    async findAll(){
        return await Card.findAll();
    }

    async findByNome(nome){
        return await Card.findOne({ where: {nome}})
    }

    async delete(id){
        await Card.destroy({where: {id}})

    }

}

module.exports = new CardRepository();