const bcrypt = require('bcrypt');
const cardRepository = require('../repositories/cardRepository');
const { v4: UUIDV4 } = require('uuid')
const jwt = require ('jsonwebtoken');

const SECRET_KEY = 'chave_secreta'

class CardService{
    async getAll(){
        return cardRepository.findAll();
    }

    async getByNome(nome){
        return cardRepository.findByNome(nome);
    }

    async register(nome, defesa, ataque, nivel, custo, urlImagem, descricao){
        if(nome === "" || nome.length < 1 || nome.length > 50){
            throw new Error;('Preencha um nome valido!');
        }
        
        if(defesa < 0 || defesa > 10){
            throw new Error('Preencha uma defesa valida!');
        }

        if(ataque < 0 || ataque > 10){
            throw new Error('Preencha um ataque valido!');
        }
        
        if (nivel < 1 || nivel > 10){
            throw new Error('Preencha um nivel valido!');
        }
        
        if  (custo < 1 || custo > 10){
            throw new Error('Preencha um custo valido!');
        }

        if (urlImagem === "" || urlImagem.length < 11 || urlImagem.length > 200){
            throw new Error('Preencha a URL da imagem!');
        }
        
        if (descricao === "" || descricao.length < 1 || descricao.length > 250){
            throw new Error('Preencha a descrição!');
        }
        

        const card = await this.getByNome(nome);

        if(card){
            throw new Error('Carta já cadastrada');
        }

        const id = UUIDV4();
        return await userRepository.createCard({
            id,
            nome,
            defesa,
            ataque,
            nivel,
            custo,
            urlImagem,
            descricao
        });
    }

    async Addcard(nome, defesa, ataque, nivel, custo, urlImagem, descricao){
        const card = await this.getByNome(nome)
        if(!card){
            throw new Error("Carta não encontrada");
        }
        const token = jwt.sign({id: user.id}, SECRET_KEY, {expiresIn: '1h'})
        return token; 
    }

    async delete(nome){
        const card = await this.getByUserName(nome);

        if(!card){
            throw new Error ('card invalido')
        }
        userRepository.delete(user.id);
    }
}

module.exports = new UserService();