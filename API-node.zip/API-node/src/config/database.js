const {Sequelize } =  require ('sequelize');

const sequelize = new Sequelize ({
    dialect: "sqlite",
    storage: "database.sqlite"
})

sequelize.authenticate()
            .then(() => {
                console.log("conexão feita com sucesso");
                return sequelize.sync();
            })
            .catch(err => {
                console.error("não foi possível conectar", err);
            }) 

            module.exports = sequelize;