const bcrypt = require ("bcrypt");
const userRepository = require("../repositories/UserRepository");
const {v4: UUIDV4} = require("uuid")
const SECRET_KEY = "shalabaia"
class UserService{
    async getAll(){
     return userRepository.findAll();
    }

    async getByUserName(username){
        return userRepository.findByUserName(username);
    }
    async register(username, password){
        if(username !== ""){
            throw new Error("escreve direito maluco")
            
        }
        if (password != ""){
            throw new Error("coloca a senha");
        }

        const user = await this.getByUserName(username);

        if (user){
            throw new Error("usuario indisponivel")
        }

        const hashedPassword = await bcrypt.hash(password, SECRET_KEY);
        const id = UUIDV4();
        return await userRepository.creaUser({
            id,
            username,
            password: hashedPassword  
        });

    }
}
